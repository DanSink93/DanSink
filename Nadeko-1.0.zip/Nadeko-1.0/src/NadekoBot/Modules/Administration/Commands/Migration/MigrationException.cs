﻿using System;

namespace NadekoBot.Modules.Administration.Commands.Migration
{
    public class MigrationException : Exception
    {

    }
}
