##Donate to NadekoBot

If you want to help Nadeko and Nadeko's team by donating, you can do that in the two of the following ways:

###Patreon

You can donate over [Patreon][Patreon] and support the project.

[![img][img]](https://www.patreon.com/nadekobot)


###PayPal

If you wish to donate over PayPal, you can send your donations to: `nadekodiscordbot@gmail.com`

[Patreon]: https://www.patreon.com/nadekobot
[img]: http://www.mister-and-me.com/wp-content/plugins/patron-button-and-widgets-by-codebard/images/patreon-medium-button.png
